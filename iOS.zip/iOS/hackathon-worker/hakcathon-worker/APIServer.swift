//
//  APIServer.swift
//  hakcathon-worker
//
//  Created by Adelina on 30.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import Foundation

class Server {
    
    //DON'T FORGET TO PUT WORKING NGROK LINK
    static let url = "http://21192f706e9c.ngrok.io"
    
    static func authentication(withParametrs parametrs: [String: Any]) -> URLRequest? {
        guard let url = URL(string: url + "/authentication") else { return nil }
        var request = URLRequest(url: url)
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parametrs, options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func registration(withParametrs parametrs: [String: Any]) -> URLRequest? {
        guard let url = URL(string: url + "/registration") else { return nil }
        var request = URLRequest(url: url)
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parametrs, options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func sendCoordinates(latitude: String, longitude: String, forUserWithLogin login: String) -> URLRequest? {
        guard let url = URL(string: url + "/add_coordinates") else { return nil }
        var request = URLRequest(url: url)
        
        let body = ["login": login, "coordinates_latitude": latitude, "coordinates_longitude": longitude]
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: body, options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func startShift(forUserLogin login: String) -> URLRequest? {
        guard let url = URL(string: url + "/shift_start") else { return nil }
        var request = URLRequest(url: url)
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: ["login": login], options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func endShift(forUserLogin login: String) -> URLRequest? {
        guard let url = URL(string: url + "/shift_stop") else { return nil }
        var request = URLRequest(url: url)
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: ["login": login], options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func sos(forUserLogin login: String) -> URLRequest? {
        guard let url = URL(string: url + "/sos_signal") else { return nil }
        var request = URLRequest(url: url)
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: ["login": login], options: []) else { return nil }
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
}
