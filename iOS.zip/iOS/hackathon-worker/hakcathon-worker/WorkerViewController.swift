//
//  WorkerViewController.swift
//  hakcathon-worker
//
//  Created by Adelina on 30.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit
import CoreLocation

class WorkerViewController: UIViewController {

    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var startShiftButton: UIButton!
    @IBOutlet weak var endShiftButton: UIButton!
    @IBOutlet weak var sosButton: UIButton!
    
    var onShift: Bool?
    var login: String?
    var name: String?
    var surname: String?
    var lastName: String?
    var lastUpdateTime: Date?
            
    private lazy var locationManager: CLLocationManager = {
        let manager = CLLocationManager()
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.delegate = self
        manager.requestAlwaysAuthorization()
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = true
        return manager
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if onShift ?? false {
            hideStartButton()
        } else {
            hideEndButton()
        }
        
        if let name = name {
            fullNameLabel.text = name
        }
    }
    
    @IBAction func sosButtonPressed(_ sender: UIButton) {
        guard let request = Server.sos(forUserLogin: login!) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
        }.resume()
        
    }
    private func hideStartButton() {
        startShiftButton.isEnabled = false
        startShiftButton.isHidden = true
        endShiftButton.isEnabled = true
        endShiftButton.isHidden = false
        sosButton.isEnabled = true
        sosButton.isHidden = false
    }
    
    private func hideEndButton() {
        startShiftButton.isEnabled = true
        startShiftButton.isHidden = false
        endShiftButton.isEnabled = false
        endShiftButton.isHidden = true
        sosButton.isEnabled = false
        sosButton.isHidden = true
    }
    
    @IBAction func startButtonPressed(_ sender: UIButton) {
        //locationManager.startMonitoring(for: <#T##CLRegion#>)
        //For future: if we will be able to get a working area (this will drop battery usage)
        lastUpdateTime = Date()
        print(lastUpdateTime!)
        hideStartButton()
        guard let request = Server.startShift(forUserLogin: login!) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
        }.resume()
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func endButtonPressed(_ sender: UIButton) {
        locationManager.stopUpdatingLocation()
        hideEndButton()
        guard let request = Server.endShift(forUserLogin: login!) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
        }.resume()
    }
    
}

extension WorkerViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if let interval = lastUpdateTime?.timeIntervalSinceNow, interval < -60 {
            lastUpdateTime = Date()
            guard let mostRecentLocation = locations.last, login != nil else {
                print("Broke on mostResentLocation and login not nil")
                return }
            //TODO:- Request logic
            guard let request = Server.sendCoordinates(latitude: mostRecentLocation.coordinate.latitude.description, longitude: mostRecentLocation.coordinate.longitude.description, forUserWithLogin: login!) else {
                print("Broke on request making")
                return }
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let response = response {
                    print(response)
                }
            }.resume()
        }
    }
}
