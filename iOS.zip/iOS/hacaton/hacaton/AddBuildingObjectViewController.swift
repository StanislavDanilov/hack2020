//
//  AddBuildingObjectViewController.swift
//  hacaton
//
//  Created by Adelina on 31.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit
import MapKit

class AddBuildingObjectViewController: UIViewController {

    @IBOutlet var tapGestureRecognizer: UITapGestureRecognizer!
    @IBOutlet weak var mapView: MKMapView!
    
    var coordinates: [CLLocationCoordinate2D] = []
    var polygon = MKPolygon()
    var objectName: String?
    var delegate: NameQueryViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        mapView?.delegate = self
        let initialLocation = CLLocation(latitude: 55.7022200, longitude: 37.6155600)
        mapView.centerToLocation(initialLocation)
    }
    
    @IBAction func clearMapButtonPressed(_ sender: UIButton) {
        coordinates = []
        mapView.removeOverlay(polygon)
        polygon = MKPolygon()
    }
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        //TODO:- Request goes here
        var latitudes = [Double]()
        var longitudes = [Double]()
        for coordinate in coordinates {
            latitudes.append((coordinate.latitude.description as NSString).doubleValue)
            longitudes.append((coordinate.longitude.description as NSString).doubleValue)
        }
        guard let request = Server.addBuildingObject(forCompanyWithId: 0, withName: objectName!, withLatitudeArray: latitudes, withLongitudeArray: longitudes) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
                self.delegate!.dismiss(animated: true, completion: nil)
            }
        }.resume()
    }
    
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: mapView)
        let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
        
        mapView.removeOverlay(polygon)
        coordinates.append(coordinate)
        switch coordinates.count {
        case 1:
            var point = [CLLocationCoordinate2D(latitude: coordinate.latitude + 0.0001, longitude: coordinate.longitude + 0.0001), CLLocationCoordinate2D(latitude: coordinate.latitude - 0.0001, longitude: coordinate.longitude + 0.0001)]
            point.append(coordinate)
            polygon = MKPolygon(coordinates: point, count: 3)
            break
        case 2:
            var point = [CLLocationCoordinate2D(latitude: coordinate.latitude + 0.000001, longitude: coordinate.longitude + 0.000001)]
            point.append(coordinates[0])
            point.append(coordinates[1])
            polygon = MKPolygon(coordinates: point, count: 3)
            break
        default:
            polygon = MKPolygon(coordinates: coordinates, count: coordinates.count)
            break
        }
        mapView.addOverlay(polygon)
                
    }
}

extension AddBuildingObjectViewController: MKMapViewDelegate, UIGestureRecognizerDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolygon {
            let renderer = MKPolygonRenderer(polygon: overlay as! MKPolygon)
            renderer.fillColor = #colorLiteral(red: 0.2851279378, green: 0.302811265, blue: 0.4437654614, alpha: 0.5036119435)
            renderer.strokeColor = #colorLiteral(red: 0.233542949, green: 0.271787107, blue: 0.4003685713, alpha: 1)
            renderer.lineWidth = 4
            return renderer
        }
        return MKOverlayRenderer()
    }
}


private extension MKMapView {
    func centerToLocation(
      _ location: CLLocation,
      regionRadius: CLLocationDistance = 38000
    ) {
      let coordinateRegion = MKCoordinateRegion(
        center: location.coordinate,
        latitudinalMeters: regionRadius,
        longitudinalMeters: regionRadius)
      setRegion(coordinateRegion, animated: true)
    }
}
