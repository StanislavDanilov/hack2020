//
//  PersonalViewController.swift
//  hacaton
//
//  Created by Adelina on 28.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class PersonalViewController: UIViewController {
    
    let personCellNibName = "PersonTableViewCell"
    let personCellId = "personTableViewCell"
    var workers = [Worker]()
    let gestureRecognizer = UITapGestureRecognizer(
      target: self,
      action: #selector(handleTap(_:))
    )

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
//        searchBar.delegate = self
        
        tableView.register(UINib.init(nibName: personCellNibName, bundle: nil), forCellReuseIdentifier: personCellId)
        tableView.dataSource = self
        tableView.delegate = self
        getData()
//        tableView.reloadData()
        
//        view.addGestureRecognizer(gestureRecognizer)
        
        
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
      view.endEditing(true)
    }
    
    private func getData() {
        //TODO:- Request logic
        //Building object id decision goes here
        guard let request = Server.getAllPersonal(forObject: 2) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            guard let data = data else { return }
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary as? [String: [String: Any]]
                guard json != nil else { return }
                for i in 0..<json!.count {
                    guard let name = json![String(i)]!["name"] as? String , let surname = json![String(i)]!["surname"] as? String, let lastName = json![String(i)]!["lastname"] as? String, let login = json![String(i)]!["login"] as? String, let position = json![String(i)]!["position"] as? String, let status = json![String(i)]!["status"] as? String else { return }
                    let worker = Worker(withName: name, withSurname: surname, withPatronymic: lastName, withLogin: login, withPosition: position)
                    status == "в процессе" ? worker.changeStatus(): nil
                    self.workers.append(worker)
                }
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch {
                print(error)
            }
        }.resume()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? WorkerViewController {
            destination.worker = workers[tableView.indexPathForSelectedRow!.row]
            tableView.deselectRow(at: tableView.indexPathForSelectedRow!, animated: true)
        }
        else if segue.description == "showAddScreen" {
            //TODO:- Prepare for AddPersonViewController
        }
    }

    @IBAction func plusButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "showAddScreen", sender: self)
    }
}



extension PersonalViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return workers.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Cell setup
        let cell = tableView.dequeueReusableCell(withIdentifier: personCellId, for: indexPath) as! PersonTableViewCell
        let worker = workers[indexPath.row]
        cell.statusImage.image = UIImage(named: worker.gerStatus() == .ofline ? "ofline.png":"online.png")
        cell.fullNameLabel.text = [worker.surname, worker.name, worker.patronymic].joined(separator: " ")
        cell.positionLabel.text = worker.position
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showWorkerInfo", sender: self)
    }
    
}

//extension PersonalViewController: UISearchBarDelegate {
//
//    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
//        self.view.addGestureRecognizer(gestureRecognizer)
//    }
//
//    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
//        self.view.removeGestureRecognizer(gestureRecognizer)
//    }
//}
