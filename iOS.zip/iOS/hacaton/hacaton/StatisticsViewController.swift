//
//  StatusticsViewController.swift
//  hacaton
//
//  Created by Adelina on 31.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class StatisticsViewController: UIViewController {

    @IBOutlet weak var firstImage: UIImageView!
    @IBOutlet weak var secondImage: UIImageView!
    
    let queue = DispatchQueue(label: "getStatistics")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let imagesArray = [firstImage, secondImage]
        for i in 1...imagesArray.count {
            wait(seconds: 0.5) {
                self.updateImage(withNumber: i) { (image) in
                    imagesArray[i - 1]?.image = image
                }
            }
        }
    }
    
    private func updateImage(withNumber num: Int, completion: @escaping (UIImage) -> Void) {
        guard var request = Server.getStatistics(grafNum: num, forObject: 2) else { return }
        request.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            if let image = UIImage(data: data!) {
                DispatchQueue.main.async {
                    completion(image)
                }
            }
        }.resume()
    }
    
    private func wait(seconds: Double, completion: @escaping () -> Void) {
        queue.asyncAfter(deadline: .now() + seconds) { completion() }
    }

}
