//
//  PersonTableViewCell.swift
//  hacaton
//
//  Created by Adelina on 28.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

@IBDesignable class PersonTableViewCell: UITableViewCell {

    @IBOutlet weak var statusImage: UIImageView!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    @IBOutlet weak var workerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        workerView.layer.cornerRadius = 12
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
