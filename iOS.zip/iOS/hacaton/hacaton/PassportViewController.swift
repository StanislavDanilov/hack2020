//
//  PassportViewController.swift
//  hacaton
//
//  Created by Adelina on 31.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class PassportViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func addButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "showAddBuildingObjectView", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
