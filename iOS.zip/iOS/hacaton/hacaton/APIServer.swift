//
//  APIServer.swift
//  hacaton
//
//  Created by Adelina on 31.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import Foundation

class Server {
    
    //DON'T FORGET TO PUT WORKING NGROK LINK
    static let url = "http://21192f706e9c.ngrok.io"
    
    static func getAllPersonal(forObject object: Int) -> URLRequest? {
        guard let url = URL(string: url + "/all_workers_on_construction_object/" + String(object)) else { return nil }
            var request = URLRequest(url: url)
            
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            return request
    }
    
    static func getStatistics(grafNum num: Int, forObject object: Int) -> URLRequest? {
        guard let url = URL(string: url + "/statistics_" + String(num) + "/" + String(object)) else { return nil }
            var request = URLRequest(url: url)
            
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            return request
    }
    
    static func addBuildingObject(forCompanyWithId id: Int, withName name: String, withLatitudeArray latitudes: [Double], withLongitudeArray longitudes: [Double]) -> URLRequest? {
        guard let url = URL(string: url + "/add_construction_object") else { return nil }
        var request = URLRequest(url: url)
            
        let body = ["id": id, "name": name, "coordinates_latitude": latitudes, "coordinated_longitude": longitudes] as [String : Any]
        guard let httpBody = try? JSONSerialization.data(withJSONObject: body, options: []) else { return nil }
        
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func getWorkerInfo(forLogin login: String) -> URLRequest? {
        guard let url = URL(string: url + "/location") else { return nil }
        var request = URLRequest(url: url)
            
        let body = ["login": login]
        guard let httpBody = try? JSONSerialization.data(withJSONObject: body, options: []) else { return nil }
        
        request.httpMethod = "POST"
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
}
