//
//  Worker.swift
//  hacaton
//
//  Created by Adelina on 28.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import Foundation

class Worker {
    let login: String
    let name: String
    let surname: String
    let patronymic: String
    let position: String
    private var status = Status.ofline
    
    init(withName name: String, withSurname surname: String, withPatronymic patronymic: String, withLogin id: String, withPosition position: String) {
        self.name = name
        self.surname = surname
        self.patronymic = patronymic
        self.position = position
        self.login = id
    }
    
    init(withName name: String, withSurname surname: String, withLogin id: String, withPosition position: String) {
        self.name = name
        self.surname = surname
        self.patronymic = ""
        self.position = position
        self.login = id
    }
    
    func changeStatus() {
        self.status = (self.status == .online ? .ofline : .online)
    }
    
    func gerStatus()-> Status {
        return self.status
    }
}

enum Status: String {
    case online = "online"
    case ofline = "ofline"
}
