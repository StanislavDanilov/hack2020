//
//  NameQueryViewController.swift
//  hacaton
//
//  Created by Adelina on 01.11.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class NameQueryViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        nameTextField.leftView = UIView(frame: CGRect(x: nameTextField.frame.minX, y: nameTextField.frame.minY, width: 20, height: nameTextField.frame.height))
        nameTextField.leftViewMode = .always
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? AddBuildingObjectViewController {
            destination.objectName = nameTextField.text
            destination.delegate = self
        }
    }
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        if nameTextField.text != "" {
            performSegue(withIdentifier: "showMap", sender: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
