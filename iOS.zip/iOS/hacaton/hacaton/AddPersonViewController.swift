//
//  AddPersonViewController.swift
//  hacaton
//
//  Created by Adelina on 29.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class AddPersonViewController: UIViewController {

    @IBOutlet weak var fullNameTextField: UITextField!
    @IBOutlet weak var positionTextField: UITextField!
    @IBOutlet weak var deviceNumTextField: UITextField!
    
    private enum TextFieldTag: Int {
        case fullName
        case position
        case deviceNum
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        textFielsSetup()
        
        view.addGestureRecognizer(
          UITapGestureRecognizer(
            target: self,
            action: #selector(handleTap(_:))
          )
        )
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
      view.endEditing(true)
    }
    
    func textFielsSetup() {
        fullNameTextField.leftView = UIView(frame: CGRect(x: fullNameTextField.frame.minX, y: fullNameTextField.frame.minY, width: 20, height: fullNameTextField.frame.height))
        fullNameTextField.leftViewMode = .always
        fullNameTextField.tag = TextFieldTag.fullName.rawValue
        
        positionTextField.leftView = UIView(frame: CGRect(x: positionTextField.frame.minX, y: positionTextField.frame.minY, width: 20, height: positionTextField.frame.height))
        positionTextField.leftViewMode = .always
        positionTextField.tag = TextFieldTag.position.rawValue
        
        deviceNumTextField.leftView = UIView(frame: CGRect(x: deviceNumTextField.frame.minX, y: deviceNumTextField.frame.minY, width: 20, height: deviceNumTextField.frame.height))
        deviceNumTextField.leftViewMode = .always
        deviceNumTextField.tag = TextFieldTag.deviceNum.rawValue
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        //TODO:- Insert registration logic
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension AddPersonViewController: UITextViewDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      guard let text = textField.text, text.count > 0 else {
        return false
      }
      switch textField.tag {
      case TextFieldTag.fullName.rawValue:
        positionTextField.becomeFirstResponder()
      case TextFieldTag.position.rawValue:
        deviceNumTextField.becomeFirstResponder()
      case TextFieldTag.deviceNum.rawValue:
        //TODO:- Insert registration logic
        break
      default:
        return false
      }
      
      return true
    }
}
