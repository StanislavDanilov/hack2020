//
//  WorkerViewController.swift
//  hacaton
//
//  Created by Adelina on 28.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit
import MapKit

class WorkerViewController: UIViewController {
    
    var worker: Worker?
    var coordinates = [CLLocationCoordinate2D]()
//    var region = MKCoordinateRegion()
    var polygon = MKPolygon()
    var currLocation: CLLocationCoordinate2D?

    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var statusImage: UIImageView!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var deviseNumLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        map.delegate = self
        map.isScrollEnabled = false
        map.isZoomEnabled = false
        map.isPitchEnabled = false
        map.isRotateEnabled = false
        setup()
        guard let request = Server.getWorkerInfo(forLogin: worker!.login) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            guard let data = data else { return }
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary as? [String:Any]
                let overlayLatitude = json!["values_latitude"] as? [Double]
                let overlayLongitude = json!["values_longitude"] as? [Double]
                for i in 0..<overlayLatitude!.count {
                    self.coordinates.append(CLLocationCoordinate2D(latitude: overlayLatitude![i], longitude: overlayLongitude![i]))
                }
                if let userLatitude = json!["coordinates_latitude"] as? Double, let userLongitude = json!["coordinates_longitude"] as? Double {
                    self.currLocation = CLLocationCoordinate2D(latitude: userLatitude, longitude: userLongitude)
                }
                DispatchQueue.main.async {
                    self.polygon = MKPolygon(coordinates: self.coordinates, count: self.coordinates.count)
                    self.map.addOverlay(self.polygon)
                    self.map.setCenter(self.coordinates[0], animated: true)
                    if self.currLocation != nil {
                        self.coordinates.append(self.currLocation!)
                        let annotation = MKPointAnnotation()
                        annotation.coordinate = self.currLocation!
                        self.map.addAnnotation(annotation)
                    }
                    self.map.setRegion(self.makeRegion(coordinates: self.coordinates), animated: true)
                    
                }
            } catch {
                print("OOOOOPS")
            }
        }.resume()
        
        
    }
    
    func setup() {
        guard worker != nil else {
            fullNameLabel.text = ""
            statusImage.image = nil
            statusLabel.text = ""
            deviseNumLabel.text = ""
            positionLabel.text = ""
            print("No worker")
            return
        }
        fullNameLabel.text = [worker!.surname, worker!.name, worker!.patronymic].joined(separator: " ")
        statusImage.image = UIImage(named: worker!.gerStatus() == .ofline ? "ofline.png":"online.png")
        statusLabel.text = worker!.gerStatus().rawValue
        statusLabel.textColor = worker!.gerStatus() == .online ? #colorLiteral(red: 0.4232589602, green: 0.8239155412, blue: 0.6677923799, alpha: 1) : #colorLiteral(red: 0.8979089856, green: 0.3760818541, blue: 0.2760255039, alpha: 1)
        deviseNumLabel.text = "1234"
        positionLabel.text = worker!.position
    }
    
    @IBAction func deleteButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backButtonPressed(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func makeRegion(coordinates:[CLLocationCoordinate2D]) -> MKCoordinateRegion {
        var rect = MKMapRect()
        var coordinates = coordinates
        if !coordinates.isEmpty {
            let first = coordinates.removeFirst()
            var top = first.latitude
            var bottom = first.latitude
            var left = first.longitude
            var right = first.longitude
            coordinates.forEach { coordinate in
                top = max(top, coordinate.latitude)
                bottom = min(bottom, coordinate.latitude)
                left = min(left, coordinate.longitude)
                right = max(right, coordinate.longitude)
            }
            let topLeft = MKMapPoint(CLLocationCoordinate2D(latitude:top, longitude:left))
            let bottomRight = MKMapPoint(CLLocationCoordinate2D(latitude:bottom, longitude:right))
            rect = MKMapRect(x:topLeft.x, y:topLeft.y,
                             width:bottomRight.x - topLeft.x, height:bottomRight.y - topLeft.y)
        }
        return MKCoordinateRegion(rect)
    }

}

extension WorkerViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }

        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)

        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
        } else {
            annotationView!.annotation = annotation
        }

        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolygon {
            let renderer = MKPolygonRenderer(polygon: overlay as! MKPolygon)
            renderer.fillColor = #colorLiteral(red: 0.2851279378, green: 0.302811265, blue: 0.4437654614, alpha: 0.5036119435)
            renderer.strokeColor = #colorLiteral(red: 0.233542949, green: 0.271787107, blue: 0.4003685713, alpha: 1)
            renderer.lineWidth = 4
            return renderer
        }
        return MKOverlayRenderer()
    }
}
