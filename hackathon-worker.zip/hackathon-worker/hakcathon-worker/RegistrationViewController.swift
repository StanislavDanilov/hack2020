//
//  RegistrationViewController.swift
//  hakcathon-worker
//
//  Created by Adelina on 30.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class RegistrationViewController: UIViewController {
    
    var login: String?
    var password: String?
    var delegate: EntryViewController?
    
    private enum TextFieldTag: Int {
        case login
        case password
        case name
        case surname
        case lastName
        case position
        case buildingObject
        case mobile
    }

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var surnameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var positionTextField: UITextField!
    @IBOutlet weak var buildingObjectTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    
    @IBOutlet weak var registrationButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        loginTextField.leftView = UIView(frame: CGRect(x: loginTextField.frame.minX, y: loginTextField.frame.minY, width: 20, height: loginTextField.frame.height))
        loginTextField.leftViewMode = .always
        loginTextField.delegate = self
        loginTextField.tag = TextFieldTag.login.rawValue
        loginTextField.text = login ?? ""
        
        passwordTextField.leftView = UIView(frame: CGRect(x: passwordTextField.frame.minX, y: passwordTextField.frame.minY, width: 20, height: passwordTextField.frame.height))
        passwordTextField.leftViewMode = .always
        passwordTextField.delegate = self
        passwordTextField.tag = TextFieldTag.password.rawValue
        passwordTextField.text = password ?? ""
        
        nameTextField.leftView = UIView(frame: CGRect(x: nameTextField.frame.minX, y: nameTextField.frame.minY, width: 20, height: nameTextField.frame.height))
        nameTextField.leftViewMode = .always
        nameTextField.delegate = self
        nameTextField.tag = TextFieldTag.name.rawValue
        
        surnameTextField.leftView = UIView(frame: CGRect(x: surnameTextField.frame.minX, y: surnameTextField.frame.minY, width: 20, height: surnameTextField.frame.height))
        surnameTextField.leftViewMode = .always
        surnameTextField.delegate = self
        surnameTextField.tag = TextFieldTag.surname.rawValue
        
        lastNameTextField.leftView = UIView(frame: CGRect(x: lastNameTextField.frame.minX, y: lastNameTextField.frame.minY, width: 20, height: lastNameTextField.frame.height))
        lastNameTextField.leftViewMode = .always
        lastNameTextField.delegate = self
        lastNameTextField.tag = TextFieldTag.lastName.rawValue
        
        positionTextField.leftView = UIView(frame: CGRect(x: positionTextField.frame.minX, y: positionTextField.frame.minY, width: 20, height: positionTextField.frame.height))
        positionTextField.leftViewMode = .always
        positionTextField.delegate = self
        positionTextField.tag = TextFieldTag.position.rawValue
        
        buildingObjectTextField.leftView = UIView(frame: CGRect(x: buildingObjectTextField.frame.minX, y: buildingObjectTextField.frame.minY, width: 20, height: buildingObjectTextField.frame.height))
        buildingObjectTextField.leftViewMode = .always
        buildingObjectTextField.delegate = self
        buildingObjectTextField.tag = TextFieldTag.buildingObject.rawValue
        
        mobileTextField.leftView = UIView(frame: CGRect(x: mobileTextField.frame.minX, y: mobileTextField.frame.minY, width: 20, height: mobileTextField.frame.height))
        mobileTextField.leftViewMode = .always
        mobileTextField.delegate = self
        mobileTextField.tag = TextFieldTag.buildingObject.rawValue
        
        activityIndicator.isHidden = true
        activityIndicator.isOpaque = false
        
        login == nil ? loginTextField.becomeFirstResponder() : nameTextField.becomeFirstResponder()
        
        view.addGestureRecognizer(
          UITapGestureRecognizer(
            target: self,
            action: #selector(handleTap(_:))
          )
        )
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
      view.endEditing(true)
    }
    
    @IBAction func registerButtonPressed(_ sender: UIButton) {
        if (loginTextField.text != "" && passwordTextField.text != "" && nameTextField.text != "" && surnameTextField.text != "" && lastNameTextField.text != "" && positionTextField.text != "" && buildingObjectTextField.text != "" && mobileTextField.text != "") {
            view.endEditing(true)
            signIn()
        } else {
            //TODO:- Ask user for login and password
        }
    }
    
    private func signIn() {
        registrationButton.isHidden = true
        registrationButton.isOpaque = false
        cancelButton.isHidden = true
        cancelButton.isOpaque = false
        activityIndicator.isHidden = false
        activityIndicator.isOpaque = true
        activityIndicator.startAnimating()
        //TODO:- Request logic goes here
        guard let request = Server.registration(withParametrs: ["login": loginTextField.text!, "password": passwordTextField.text!, "name": nameTextField.text!, "surname": surnameTextField.text!, "lastname": lastNameTextField.text!, "position": positionTextField.text!, "buildingobject": buildingObjectTextField.text!, "phonenumber": mobileTextField.text!]) else { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard response != nil else { return }
                            
            guard let data = data else { return }
            var success = false
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary
                if ((json!["answer"] as? String)?.contains("success"))! {
                    success = true
                } else {
                    print("Error while regestrating")
                }
            } catch {
                print(error)
            }
            DispatchQueue.main.async {
                if success {
                    self.performSegue(withIdentifier: "showWorkerView", sender: self)
                    print("Success")
                } else {
                    print("Eror occur")
                }
                return
            }
        }.resume()
        return
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showWorkerView" {
            //TODO:- Prepare for segue
            guard let destination = segue.destination as? WorkerViewController else {
                print("Couldn't find correct destination")
                return
            }
            destination.onShift = false
            destination.login = loginTextField.text!
            destination.name = nameTextField.text!
            destination.surname = surnameTextField.text!
            destination.lastName = lastNameTextField.text!
        }
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIButton) {
        delegate?.returnToNormal()
        self.dismiss(animated: true, completion: nil)
    }

}

extension RegistrationViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      guard let text = textField.text, text.count > 0 else {
        return false
      }
      
      switch textField.tag {
      case TextFieldTag.login.rawValue:
        passwordTextField.becomeFirstResponder()
      case TextFieldTag.password.rawValue:
        nameTextField.becomeFirstResponder()
      case TextFieldTag.name.rawValue:
        surnameTextField.becomeFirstResponder()
      case TextFieldTag.surname.rawValue:
        lastNameTextField.becomeFirstResponder()
      case TextFieldTag.lastName.rawValue:
        positionTextField.becomeFirstResponder()
      case TextFieldTag.position.rawValue:
        buildingObjectTextField.becomeFirstResponder()
      case TextFieldTag.buildingObject.rawValue:
        mobileTextField.becomeFirstResponder()
      case TextFieldTag.mobile.rawValue:
        signIn()
      default:
        return false
      }
      return true
    }
}
