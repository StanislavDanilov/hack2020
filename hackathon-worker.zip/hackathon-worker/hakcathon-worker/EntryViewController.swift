//
//  EntryViewController.swift
//  hakcathon-worker
//
//  Created by Adelina on 30.10.2020.
//  Copyright © 2020 AdelineHramtz. All rights reserved.
//

import UIKit

class EntryViewController: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var enterButton: UIButton!
    
    var name: String?
    var surname: String?
    var lastName: String?
    var onShift: Bool?
    
    private enum TextFieldTag: Int {
            case login
            case password
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            
            loginTextField.leftView = UIView(frame: CGRect(x: loginTextField.frame.minX, y: loginTextField.frame.minY, width: 20, height: loginTextField.frame.height))
            loginTextField.leftViewMode = .always
            loginTextField.delegate = self
            loginTextField.tag = TextFieldTag.login.rawValue
            
            passwordTextField.leftView = UIView(frame: CGRect(x: passwordTextField.frame.minX, y: passwordTextField.frame.minY, width: 20, height: passwordTextField.frame.height))
            passwordTextField.leftViewMode = .always
            passwordTextField.delegate = self
            passwordTextField.tag = TextFieldTag.password.rawValue
            
            activityIndicator.isHidden = true
            activityIndicator.isOpaque = false
            
            view.addGestureRecognizer(
              UITapGestureRecognizer(
                target: self,
                action: #selector(handleTap(_:))
              )
            )
        }
        
        @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
          view.endEditing(true)
        }

    @IBAction func registerButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "showRegisterView", sender: self)
    }
    
    @IBAction func enterButtonPressed(_ sender: Any) {
            if (loginTextField.text != "" && passwordTextField.text != "") {
                view.endEditing(true)
                signIn()
            } else {
                //TODO:- Ask user for login and password
            }
        }
    
    func returnToNormal() {
        enterButton.isHidden = false
        enterButton.isOpaque = true
        activityIndicator.isHidden = true
        activityIndicator.isOpaque = false
    }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showRegisterView" {
            guard let destination = segue.destination as? RegistrationViewController else {
                print("Couldn't find correct destination")
                return
            }
            destination.login = loginTextField.text == "" ? nil : loginTextField.text
            destination.password = passwordTextField.text == "" ? nil : passwordTextField.text
            destination.delegate = self
        } else if segue.identifier == "showWorkerView" {
            guard let destination = segue.destination as? WorkerViewController else {
                print("Couldn't find correct destination")
                return
            }
            destination.name = self.name
            destination.surname = self.surname
            destination.lastName = self.lastName
            destination.login = loginTextField.text!
            destination.onShift = self.onShift
        }
    }
    
    private func signIn() {
        guard let login = loginTextField.text, login.count > 0 else {
          return
        }
        guard let password = passwordTextField.text, password.count > 0 else {
          return
        }
        enterButton.isHidden = true
        enterButton.isOpaque = false
        activityIndicator.isHidden = false
        activityIndicator.isOpaque = true
        activityIndicator.startAnimating()
        
        guard let request = Server.authentication(withParametrs: ["login": login, "password": password]) else  { return }
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard response != nil else { return }
                            
            guard let data = data else { return }
            var success = false
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary
                if ((json!["answer"] as? String)?.contains("success"))! {
                    success = true
                    self.name = json!["name"] as? String
                    self.surname = json!["surname"] as? String
                    self.lastName = json!["lastname"] as? String
                    self.onShift = (json!["status"] as? String) == "в процессе" ? true:false
                } else {
                    print("No such person")
                }
            } catch {
                print(error)
            }
            DispatchQueue.main.async {
                if success {
                    self.performSegue(withIdentifier: "showWorkerView", sender: self)
                } else {
                    self.performSegue(withIdentifier: "showRegisterView", sender: self)
                }
                return
            }
        }.resume()
        return
    }
    
}

extension EntryViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      guard let text = textField.text, text.count > 0 else {
        return false
      }
      switch textField.tag {
      case TextFieldTag.login.rawValue:
        passwordTextField.becomeFirstResponder()
      case TextFieldTag.password.rawValue:
        signIn()
      default:
        return false
      }
      
      return true
    }
}

